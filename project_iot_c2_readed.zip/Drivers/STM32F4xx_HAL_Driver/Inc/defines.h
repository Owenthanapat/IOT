/*
 * defines.h
 *
 *  Created on: Dec 12, 2019
 *      Author: user
 */

//#ifndef STM32F4XX_HAL_DRIVER_INC_DEFINES_H_
#define STM32F4XX_HAL_DRIVER_INC_DEFINES_H_


#define MPU6050_I2C I2C1
#define MPU6050_I2C_PINSPACK TM_I2C_PinsPack_1
//#endif /* STM32F4XX_HAL_DRIVER_INC_DEFINES_H_ */
